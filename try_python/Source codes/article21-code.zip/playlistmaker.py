#!/usr/bin/env python

import sys
from mutagen.mp3 import MP3

try:
    import pygtk
    pygtk.require("2.0")
except:
    pass
try:
    import gtk
    import gtk.glade
except:
    sys.exit(1)
    
class PlayListMaker:
    def __init__(self):
        #================================================================
        #                     Window Creation 
        #================================================================
        self.gladefile = "playlistmaker.glade"
        self.wTree = gtk.glade.XML(self.gladefile,"MainWindow")
        #================================================================
        #                  Create Event Handlers
        #================================================================        
        dict = {"on_MainWindow_destroy": gtk.main_quit,
                "on_tbtnQuit_clicked": gtk.main_quit}

        self.wTree.signal_autoconnect(dict)
        

if __name__ == "__main__":
	plm = PlayListMaker()
	gtk.main()