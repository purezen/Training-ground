#!/usr/bin/env python 
# CursesExample2
import curses 
#========================================================== 
#                       MAIN LOOP 
#========================================================== 
try: 
    myscreen = curses.initscr() 
    myscreen.clear() 
    myscreen.addstr(0,0,"0        1         2         3         4         5         6         7") 
    myscreen.addstr(1,0,"12345678901234567890123456789012345678901234567890123456789012345678901234567890") 
    myscreen.addstr(10,0,"10") 
    myscreen.addstr(20,0,"20") 
    myscreen.addstr(23,0, "23 - Press Any Key to Continue") 
    myscreen.refresh() 
    myscreen.getch() 
finally: 
    curses.endwin() 
