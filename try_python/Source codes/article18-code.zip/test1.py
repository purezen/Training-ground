test1 = "the time has come" + chr(13) + chr(10)
test2 = "for all good men" + chr(13) + chr(10)
test3 = "to come to the aid of the party" + chr(13) + chr(10)
test4 = test1+test2+test3
print test4[:3] + "|"
