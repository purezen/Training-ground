#widgetdemo2f.py (full demo program)
import sys
from Tkinter import *
import ttk
#import tkMessageBox
#import tkFont
#import tkFileDialog

class WidgetDemo2:
    #------------------------------------------------------------------
    #
    #------------------------------------------------------------------
    def __init__(self,master = None):
        self.DefineVars()
        f = self.BuildWidgets(master)
        self.PlaceWidgets(f)

        
    #------------------------------------------------------------------
    #
    #------------------------------------------------------------------    
    def DefineVars(self):
        self.cmbo1Val = StringVar()
        self.c1Vals = ['None','Option 1','Option 2','Option 3']
        
        self.spinval = StringVar()
        
        self.spinval2 = StringVar()
        self.btnStatus = False
        self.pbar2val = StringVar()
        
        
    def FileNew(self):
        print "Menu - File New"
    def FileOpen(self):
        print "Menu - File Open"
    def FileSave(self):
        print "Menu - File Save"
    def EditCut(self):
        print "Menu - Edit Cut"
    def EditCopy(self):
        print "Menu - Edit Copy"
    def EditPaste(self):
        print "Menu - Edit Paste"
    def HelpAbout(self):
        print "Menu - Help About"
        
    #------------------------------------------------------------------
    #
    #------------------------------------------------------------------    
    def BuildWidgets(self,master):
        frame = Frame(master)
        #==============================================================
        #                          MENU STUFF
        #==============================================================
        # Create the menu bar
        self.menubar = Menu(master)
        # Create the File Pulldown, and add it to the menu bar
        filemenu = Menu(self.menubar, tearoff = 0)
        filemenu.add_command(label = "New", command = self.FileNew)
        filemenu.add_command(label = "Open", command = self.FileOpen)
        filemenu.add_command(label = "Save", command = self.FileSave)
        filemenu.add_separator()
        filemenu.add_command(label = "Exit", command = root.quit)
        self.menubar.add_cascade(label = "File", menu = filemenu)
        # Create the Edit Pulldown
        editmenu = Menu(self.menubar, tearoff = 0)
        editmenu.add_command(label = "Cut", command = self.EditCut)
        editmenu.add_command(label = "Copy", command = self.EditCopy)
        editmenu.add_command(label = "Paste", command = self.EditPaste)
        self.menubar.add_cascade(label = "Edit", menu = editmenu)
        # Create the Help Pulldown
        helpmenu = Menu(self.menubar, tearoff=0)
        helpmenu.add_command(label = "About", command = self.HelpAbout)
        self.menubar.add_cascade(label = "Help", menu = helpmenu)
         # Now, display the menu
        master.config(menu = self.menubar) 
        #==============================================================
        #                  End of Menu Stuff
        #==============================================================
        self.f1 = Frame(frame,
                        relief = SUNKEN,
                        borderwidth = 2, 
                        width = 500
                        )
        self.lblcb = Label(self.f1, text = "Combo Box: ")
        self.cmbo1 = ttk.Combobox(self.f1, 
                                  height = "19",
                                  width = 20, 
                                  textvariable = self.cmbo1Val
                                 )
        self.cmbo1['values'] = self.c1Vals 
        # Bind the virtual event to the callback
        self.cmbo1.bind("<<ComboboxSelected>>",self.cmbotest)
        self.fsep = Frame(self.f1,
                          width = 140,
                          height = 2,
                          relief = RIDGE,
                          borderwidth = 2
                          )
        self.lblsc = Label(self.f1, text = "Spin Control:")
        self.spin1 = Spinbox(self.f1, 
                             from_ = 1.0, 
                             to = 10.0, 
                             width = 3,
                             textvariable = self.spinval,
                             wrap=True
                             )
        #=======================================
        # Progress Bar Stuff
        #=======================================
        self.frmPBar = Frame(self.f1,
                        relief = SUNKEN,
                        borderwidth = 2
                        )

        self.lbl0 = Label(self.frmPBar,
                        text = "Progress Bars"
                        )
        self.lbl1 = Label(self.frmPBar,
                        text = "Indeterminate",
                        anchor = 'e'
                        )
        self.pbar = ttk.Progressbar(self.frmPBar, 
                        orient = HORIZONTAL, 
                        length = 100, 
                        mode = 'indeterminate',
                        maximum = 100
                        )
        self.btnptest = Button(self.frmPBar,
                        text = "Start",
                        command = self.TestPBar
                        )
        self.lbl2 = Label(self.frmPBar,
                        text = "Determinate"
                        )
        self.pbar2 = ttk.Progressbar(self.frmPBar,
                        orient = HORIZONTAL,
                        length = 100,
                        mode = 'determinate',
                        variable = self.pbar2val
                        )
        self.spin2 = Spinbox(self.frmPBar, 
                        from_ = 1.0, 
                        to = 100.0, 
                        textvariable = self.spinval2,
                        wrap = True,
                        width = 5,
                        command = self.Spin2Do
                        )
        #=======================================
        #              NOTEBOOK
        #=======================================
        self.nframe = Frame(self.f1,
                            relief = SUNKEN,
                            borderwidth = 2,
                            width = 500,
                            height = 300
                            )
        self.notebook = ttk.Notebook(self.nframe,
                                     width = 490,
                                     height = 290
                                     )
        self.p1 = Frame(self.notebook)
        self.p2 = Frame(self.notebook)
        self.notebook.add(self.p1,text = 'Page One')
        self.notebook.add(self.p2,text = 'Page Two')
        self.lsp1 = Label(self.p1,
                          text = "This is a label on page number 1",
                          padx = 3,
                          pady = 3
                          )
        
        return frame
        
    #------------------------------------------------------------------
    #
    #------------------------------------------------------------------
    def PlaceWidgets(self,master):
        frame = master
        frame.grid(column = 0, row = 0)
       
        self.f1.grid(column = 0,row = 0)
        self.lblcb.grid(column = 0,row = 2)
        self.cmbo1.grid(column = 1,
                        row = 2,
                        columnspan = 4,
                        pady = 2
                        )
        self.fsep.grid(column = 0,
                       row = 3,
                       columnspan = 8,
                       sticky = 'we',
                       padx = 3,
                       pady = 3
                       )
        self.lblsc.grid(column = 0, row = 4)
        self.spin1.grid(column = 1, 
                        row = 4,
                        pady = 2
                        )
        
        # Progress Bar
        self.frmPBar.grid(column = 0,
                        row = 5,
                        columnspan = 8,
                        sticky = 'nsew',
                        padx = 3,
                        pady = 3
                        )
        self.lbl0.grid(column = 0, row = 0)
        self.lbl1.grid(column = 0, 
                       row = 1, 
                       pady = 3
                       )
        self.pbar.grid(column = 1, row = 1)
        self.btnptest.grid(column = 3, row = 1)
        self.lbl2.grid(column = 0, 
                       row = 2, 
                       pady = 3
                       )
        self.pbar2.grid(column = 1, row = 2)
        self.spin2.grid(column = 3, row = 2)
        self.nframe.grid(column = 0,
                         row = 6,
                         columnspan = 8,
                         rowspan = 7,
                         sticky = 'nsew'
                         )
        self.notebook.grid(column = 0,
                           row = 0,
                           columnspan = 11,
                           sticky = 'nsew'
                           )
        self.lsp1.grid(column = 0,row = 0)
        self.lsp2 = Label(self.p2,
                          text = 'This is a label on PAGE 2',
                          padx = 3,
                          pady = 3
                          ).grid(
                                 column = 0,
                                 row = 1
                                 )

    def cmbotest(self,p1):
        print self.cmbo1Val.get()
        
    def TestPBar(self):
        if self.btnStatus == False:
            self.btnptest.config(text="Stop")
            self.btnStatus = True
            self.pbar.start(10)
        else:
            self.btnptest.config(text="Start")
            self.btnStatus = False
            self.pbar.stop()
    
    def Spin2Do(self):
        v = self.spinval2.get()
        print v
        #self.pbar2.value = float(v)
        self.pbar2val.set(v)
        
if __name__ == '__main__':
    def Center(window):
        # Get the width and height of the screen
        sw = window.winfo_screenwidth()
        sh = window.winfo_screenheight()        
        # Get the width and height of the window
        rw = window.winfo_reqwidth()
        rh = window.winfo_reqheight()
        xc = (sw-rw)/2
        yc = (sh-rh)/2
        print "{0}x{1}".format(rw,rh)
        window.geometry("%dx%d+%d+%d"%(rw,rh,xc,yc))
        window.deiconify()
    
    root = Tk()
    root.title('More Widgets Demo')
    demo = WidgetDemo2(root)   
    root.after(13,Center,root)
    root.mainloop()                


