#!/usr/bin/python           # This is client.py file
# client1.py
#========================================================
import socket               # Import socket module

soc = socket.socket()         # Create a socket object
hostname = socket.gethostname() # Get local machine name
port = 21000                # Reserve a port for your service.

soc.connect((hostname, port))
print soc.recv(1024)
soc.close                     # Close the socket when done

