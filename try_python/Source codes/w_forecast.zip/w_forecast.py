from xml.etree import ElementTree as ET
import urllib
import sys
import getopt

class ForecastInfo: 
    def __init__(self):
        self.forecastText = []  # Today/tonight forecast information
        self.Title = []         # Today/tonight
        self.date = ''          
        self.icon = []          # Icon to use for conditions today/tonight
        self.periods = 0
        self.period = 0
        #===========================================================
        # Extended forecast information
        #===========================================================        
        self.extIcon = []       # Icon to use for extended forecast
        self.extDay = []        # Day text for this forecast ("Monday", "Tuesday" etc)
        self.extHigh = []       # High Temp. (F)
        self.extHighC = []      # High Temp. (C)
        self.extLow = []        # Low Temp. (F)
        self.extLowC = []       # Low Temp. (C)
        self.extConditions = [] # Conditions text
        self.extPeriod = []     # Numerical Period information (counter)
        self.extpop = []           # Percent chance Of Precipitation

    def GetForecastData(self,location):
        try:
            forecastdata = 'http://api.wunderground.com/auto/wui/geo/ForecastXML/index.xml?query=%s' % location
            urllib.socket.setdefaulttimeout(8)
            usock = urllib.urlopen(forecastdata)
            tree = ET.parse(usock)
            usock.close()
        except:
            print 'ERROR - Forecast - Could not get information from server...'
            sys.exit(2)

        #===========================================================    
        # Get the forecast for today and (if available) tonight
        #===========================================================
        fcst = tree.find('.//txt_forecast')
        for f in fcst:
            if f.tag == 'number':
                self.periods = f.text
            elif f.tag == 'date':
                self.date = f.text
            for subelement in f:
                if subelement.tag == 'period':
                    self.period=int(subelement.text)
                if subelement.tag == 'fcttext':
                    self.forecastText.append(subelement.text)
                elif subelement.tag == 'icon':
                    self.icon.append( subelement.text)
                elif subelement.tag == 'title':
                    self.Title.append(subelement.text)
        #===========================================================
        # Now get the extended forecast
        #===========================================================
        fcst = tree.find('.//simpleforecast')
        for f in fcst:
             for subelement in f:
                if subelement.tag == 'period':
                    self.extPeriod.append(subelement.text)
                elif subelement.tag == 'conditions':
                    self.extConditions.append(subelement.text)
                elif subelement.tag == 'icon':
                    self.extIcon.append(subelement.text)
                elif subelement.tag == 'pop':
                    self.extpop.append(subelement.text)
                elif subelement.tag == 'date':
                    for child in subelement.getchildren():
                        if child.tag == 'weekday':
                            self.extDay.append(child.text)
                elif subelement.tag == 'high':
                    for child in subelement.getchildren():
                        if child.tag == 'fahrenheit':
                            self.extHigh.append(child.text)
                        if child.tag == 'celsius':
                            self.extHighC.append(child.text)
                elif subelement.tag == 'low':
                    for child in subelement.getchildren():
                        if child.tag == 'fahrenheit':
                            self.extLow.append(child.text)
                        if child.tag == 'celsius':
                            self.extLowC.append(child.text)
                            
    def output(self,US,IncludeToday,Output):
        # US takes 0,1 or 2
        #   0 = Centegrade
        #   1 = Farenheit
        #   2 = both (if available)
        # Now print it all
        if Output == 0:
            for c in range(int(self.period)):
                if c <> 1:
                    print '----------------------------------------'
                print 'Forecast for %s' % self.Title[c].lower()
                print 'Forecast = %s' % self.forecastText[c]
                print 'ICON=%s' % self.icon[c]
                print '----------------------------------------'
            print 'Extended Forecast...'
            if IncludeToday == 1:
                startRange = 0
            else:
                startRange = 1
            for c in range(startRange,6):
                print self.extDay[c]
                if US == 0: #Centegrade information
                    print '\tHigh - %s(C)' % self.extHigh[c]
                    print '\tLow - %s(C)' % self.extLow[c]
                elif US == 1: #Farenheit information
                    print '\tHigh - %s(F)' % self.extHigh[c]
                    print '\tLow - %s(F)' % self.extLow[c]
                else: #US == 2 both(if available)
                    print '\tHigh - %s' % self.extHigh[c]
                    print '\tLow - %s' % self.extLow[c]
                if int(self.extpop[c]) == 0:
                    print '\tConditions - %s.' % self.extConditions[c]
                else:
                    print '\tConditions - %s.  %d%% chance of precipitation.' % (self.extConditions[c],int(self.extpop[c]))
            
    def DoIt(self,Location,US,IncludeToday,Output):
        self.GetForecastData(Location)
        self.output(US,IncludeToday,Output)

forecast = ForecastInfo()
forecast.DoIt('80013',1,0,0) # Insert your own postal code 