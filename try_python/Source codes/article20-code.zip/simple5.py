# simple6.py
import pygtk
pygtk.require('2.0')
import gtk

class Simple:
     def __init__(self):
          self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
          self.window.set_position(gtk.WIN_POS_CENTER)
          self.window.set_title("Simple 6.py")
          self.window.set_border_width(10)
          self.window.connect("delete_event", self.delete_event)
          self.button = gtk.Button("Close Me")
          self.button.connect("clicked",self.btn1Clicked,None)
          self.window.add(self.button)
          self.button.show()
          self.window.show()

     def main(self):
          gtk.main()

     def delete_event(self, widget, event, data=None):
          gtk.main_quit()
          return False

     def btn1Clicked(self,widget,data=None):
          print "Button 1 clicked"
          gtk.main_quit()

if __name__ == "__main__":
     simple = Simple()
     simple.main()
