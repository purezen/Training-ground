# widgetdemo1d.py
# Add text boxes

from Tkinter import *

class Demo:
    def __init__(self,master):
        self.DefineVars()
        f = self.BuildWidgets(master)
        self.PlaceWidgets(f)
        
    def BuildWidgets(self,master):
        # Define our widgets
        frame = Frame(master)
        # Labels
        self.lblframe = Frame(frame,relief = SUNKEN,padx = 3, pady = 3, borderwidth = 2, width = 500)
        self.lbl1 = Label(self.lblframe,text="Flat Label",relief = FLAT, width = 13,borderwidth = 2)
        self.lbl2 = Label(self.lblframe,text="Sunken Label", relief = SUNKEN, width = 13, borderwidth = 2)
        self.lbl3 = Label(self.lblframe,text="Ridge Label", relief = RIDGE, width = 13, borderwidth = 2)
        self.lbl4 = Label(self.lblframe,text="Raised Label", relief = RAISED, width = 13, borderwidth = 2)
        self.lbl5 = Label(self.lblframe,text="Groove Label", relief = GROOVE,width = 13, borderwidth = 2)
        # Buttons
        self.btnframe = Frame(frame,relief = SUNKEN,padx = 3, pady = 3, borderwidth = 2, width = 500)
        self.btn1 = Button(self.btnframe,text="Flat Button", relief = FLAT, borderwidth = 2)
        self.btn2 = Button(self.btnframe,text="Sunken Button", relief = SUNKEN, borderwidth = 2)
        self.btn3 = Button(self.btnframe,text="Ridge Button", relief = RIDGE, borderwidth = 2)
        self.btn4 = Button(self.btnframe,text="Raised Button", relief = RAISED, borderwidth = 2)
        self.btn5 = Button(self.btnframe,text="Groove Button", relief = GROOVE, borderwidth = 2)
        self.btn1.bind('<ButtonRelease-1>',lambda e: self.BtnCallback(1))
        self.btn2.bind('<ButtonRelease-1>',lambda e: self.BtnCallback(2))
        self.btn3.bind('<ButtonRelease-1>',lambda e: self.BtnCallback(3))
        self.btn4.bind('<ButtonRelease-1>',lambda e: self.BtnCallback(4))
        self.btn5.bind('<ButtonRelease-1>',lambda e: self.BtnCallback(5))
        # Check Boxes
        self.cbframe = Frame(frame, relief = SUNKEN, padx = 3, pady = 3, borderwidth = 2, width = 500)
        self.chk1 = Checkbutton(self.cbframe, text = "Normal Checkbox",variable=self.Chk1Val)
        self.chk2 = Checkbutton(self.cbframe, text = "Checkbox",variable=self.Chk2Val,indicatoron = False)
        self.chk1.bind('<ButtonRelease-1>',lambda e: self.ChkBoxClick(1))
        self.chk2.bind('<ButtonRelease-1>',lambda e: self.ChkBoxClick(2))
        self.btnToggleCB = Button(self.cbframe,text="Toggle Cbs")
        self.btnToggleCB.bind('<ButtonRelease-1>',self.btnToggle)
        # Radio Buttons
        self.rbframe = Frame(frame, relief = SUNKEN, padx = 3, pady = 3, borderwidth = 2, width = 500)
        self.rb1 = Radiobutton(self.rbframe, text = "Radio 1", variable = self.RBVal, value = 1)
        self.rb2 = Radiobutton(self.rbframe, text = "Radio 2", variable = self.RBVal, value = 2)
        self.rb3 = Radiobutton(self.rbframe, text = "Radio 3", variable = self.RBVal, value = 3)
        self.rb1.bind('<ButtonRelease-1>',lambda e: self.RBClick())
        self.rb2.bind('<ButtonRelease-1>',lambda e: self.RBClick())
        self.rb3.bind('<ButtonRelease-1>',lambda e: self.RBClick())
        self.rb4 = Radiobutton(self.rbframe, text = "Radio 4", variable = self.RBVal2, value = "1-1")
        self.rb5 = Radiobutton(self.rbframe, text = "Radio 5", variable = self.RBVal2, value = "1-2")
        self.rb6 = Radiobutton(self.rbframe, text = "Radio 6", variable = self.RBVal2, value = "1-3")
        self.rb4.bind('<ButtonRelease-1>',lambda e: self.RBClick2())
        self.rb5.bind('<ButtonRelease-1>',lambda e: self.RBClick2())
        self.rb6.bind('<ButtonRelease-1>',lambda e: self.RBClick2())                    
        # Text Boxes
        self.tbframe = Frame(frame, relief = SUNKEN, padx = 3, pady = 3, borderwidth = 2, width = 500)
        self.txt1 = Entry(self.tbframe, width = 10)
        self.txt2 = Entry(self.tbframe, disabledbackground="#cccccc", width = 10)
        self.btnDisable = Button(self.tbframe, text = "Enable/Disable")
        self.btnDisable.bind('<ButtonRelease-1>', self.btnDisableClick)
        
        return frame
        
    def PlaceWidgets(self, master):
        frame = master
        # Place the widgets
        frame.grid(column = 0, row = 0)
        # Place the labels
        self.lblframe.grid(column = 0, row = 1, padx = 5, pady = 5, columnspan = 5,sticky='WE')
        l = Label(self.lblframe,text='Labels |',width=15, anchor='e').grid(column=0,row=0)
        self.lbl1.grid(column = 1, row = 0, padx = 3, pady = 5)
        self.lbl2.grid(column = 2, row = 0, padx = 3, pady = 5)
        self.lbl3.grid(column = 3, row = 0, padx = 3, pady = 5)
        self.lbl4.grid(column = 4, row = 0, padx = 3, pady = 5)
        self.lbl5.grid(column = 5, row = 0, padx = 3, pady = 5)
        # Place the buttons
        self.btnframe.grid(column=0, row = 2, padx = 5, pady = 5, columnspan = 5,sticky = 'WE')
        l = Label(self.btnframe,text='Buttons |',width=15, anchor='e').grid(column=0,row=0)
        self.btn1.grid(column = 1, row = 0, padx = 3, pady = 3)
        self.btn2.grid(column = 2, row = 0, padx = 3, pady = 3)
        self.btn3.grid(column = 3, row = 0, padx = 3, pady = 3)
        self.btn4.grid(column = 4, row = 0, padx = 3, pady = 3)
        self.btn5.grid(column = 5, row = 0, padx = 3, pady = 3)     
        # Place the Checkboxes and toggle button
        self.cbframe.grid(column = 0, row = 3, padx = 5, pady = 5, columnspan = 5,sticky = 'WE')
        l = Label(self.cbframe,text='Check Boxes |',width=15, anchor='e').grid(column=0,row=0)
        self.btnToggleCB.grid(column = 1, row = 0, padx = 3, pady = 3)                   
        self.chk1.grid(column = 2, row = 0, padx = 3, pady = 3)
        self.chk2.grid(column = 3, row = 0, padx = 3, pady = 3)
        # Place the Radio Buttons and select the first one
        self.rbframe.grid(column = 0, row = 4, padx = 5, pady = 5, columnspan = 5,sticky = 'WE')
        l = Label(self.rbframe,text='Radio Buttons |',width=15,anchor='e').grid(column=0,row=0)
        self.rb1.grid(column = 2, row = 0, padx = 3, pady = 3, sticky = 'EW')
        self.rb2.grid(column = 3, row = 0, padx = 3, pady = 3, sticky = 'WE')
        self.rb3.grid(column = 4, row = 0, padx = 3, pady = 3, sticky = 'WE')
        self.RBVal.set("1")        
        l = Label(self.rbframe,text='| Another Set |',width = 15, anchor = 'e').grid(column = 5, row = 0)
        self.rb4.grid(column = 6, row = 0)
        self.rb5.grid(column = 7, row = 0)
        self.rb6.grid(column = 8, row = 0)
        self.RBVal2.set("1-1")        
        # Place the Text boxes
        self.tbframe.grid(column = 0, row = 5, padx = 5, pady = 5, columnspan = 5,sticky = 'WE')
        l = Label(self.tbframe,text='Text Boxes |',width=15, anchor='e').grid(column=0,row=0)
        self.txt1.grid(column = 2, row = 0, padx = 3, pady = 3)
        self.txt2.grid(column = 3, row = 0, padx = 3, pady = 3)
        self.btnDisable.grid(column = 1, row = 0, padx = 3, pady = 3)
        
    def DefineVars(self):
        # Define our resources
        self.Chk1Val = IntVar()
        self.Chk2Val = IntVar()
        self.RBVal = IntVar()
        self.RBVal2 = StringVar()        
        self.Disabled = False
        
    def BtnCallback(self,val):
        if val == 1:
            print("Flat Button Clicked...")
        elif val == 2:
            print("Sunken Button Clicked...")
        elif val == 3:
            print("Ridge Button Clicked...")
        elif val == 4:
            print("Raised Button Clicked...")
        elif val == 5:
            print("Groove Button Clicked...")
                    
    def btnToggle(self,p1):
        self.chk1.toggle()
        self.chk2.toggle()
        print("Check box 1 value is {0}".format(self.Chk1Val.get()))
        print("Check box 2 value is {0}".format(self.Chk2Val.get()))        
        
    def ChkBoxClick(self,val):
        if val == 1:
            print("Check box 1 value is {0}".format(self.Chk1Val.get()))
        elif val == 2:
            print("Check box 2 value is {0}".format(self.Chk2Val.get()))

    def RBClick(self):
        print("Radio Button clicked - Value is {0}".format(self.RBVal.get()))        
    def RBClick2(self):
        print("Radio Button clicked - Value is {0}".format(self.RBVal2.get()))        
                
    def btnDisableClick(self,p1):
        if self.Disabled == False:
            self.Disabled = True
            self.txt2.configure(state='disabled')
        else:
            self.Disabled = False
            self.txt2.configure(state='normal')
            
root = Tk()
root.geometry('750x270+150+150')
root.title("Widget Demo 1")
demo = Demo(root)

root.mainloop()
