# widgetdemo1.py
# Labels
from Tkinter import *

class Demo:
    def __init__(self,master):
        self.DefineVars()
        self.picture = PhotoImage("info.gif")
        f = self.BuildWidgets(master)
        self.PlaceWidgets(f)
        
    def BuildWidgets(self,master):
        # Define our widgets
        frame = Frame(master)
        # Labels
        self.lblframe = Frame(frame,relief = SUNKEN,padx = 3, pady = 3, 
                              borderwidth = 2, width = 500)
        self.lbl1 = Label(self.lblframe,text="Flat Label",relief = FLAT,
                          width = 13,borderwidth = 2)
        self.lbl2 = Label(self.lblframe,text="Sunken Label", relief = SUNKEN, 
                          width = 13, borderwidth = 2)
        self.lbl3 = Label(self.lblframe,text="Ridge Label", relief = RIDGE, 
                          width = 13, borderwidth = 2)
        self.lbl4 = Label(self.lblframe,text="Raised Label", 
                          relief = RAISED, width = 13, borderwidth = 2)
        self.lbl5 = Label(self.lblframe,text="Groove Label", relief = GROOVE,
                          width = 13, borderwidth = 2)
        return frame
        
    def PlaceWidgets(self, master):
        frame = master
        # Place the widgets
        frame.grid(column = 0, row = 0)
        # Place the labels
        self.lblframe.grid(column = 0, row = 1, padx = 5, pady = 5, 
                           columnspan = 5,sticky='WE')
        l = Label(self.lblframe,text='Labels |', 
                  anchor='e',image=self.picture,compound=LEFT).grid(column=0,row=0)
        self.lbl1.grid(column = 1, row = 0, padx = 3, pady = 5)
        self.lbl2.grid(column = 2, row = 0, padx = 3, pady = 5)
        self.lbl3.grid(column = 3, row = 0, padx = 3, pady = 5)
        self.lbl4.grid(column = 4, row = 0, padx = 3, pady = 5)
        self.lbl5.grid(column = 5, row = 0, padx = 3, pady = 5)
        
    def DefineVars(self):
        # Define our resources
        pass

        
        
root = Tk()
root.geometry('750x40+150+150')
root.title("Widget Demo 1")
demo = Demo(root)

root.mainloop()
