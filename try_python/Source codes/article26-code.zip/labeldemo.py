from Tkinter import *

class Demo:
    def __init__(self,master):
        self.DefineVars()
        f = self.BuildWidgets(master)
        self.PlaceWidgets(f)
        
    def BuildWidgets(self,master):
        # Define our widgets
        frame = Frame(master)
        # Labels
        self.lbl1 = Label(frame,text="Flat Label",relief = FLAT, borderwidth = 2)
        self.lbl2 = Label(frame,text="Sunken Label", relief = SUNKEN,borderwidth = 2)
        self.lbl3 = Label(frame,text="Ridge Label", relief = RIDGE,borderwidth = 2)
        self.lbl4 = Label(frame,text="Raised Label", relief = RAISED,borderwidth = 2)
        self.lbl5 = Label(frame,text="Groove Label", relief = GROOVE,borderwidth = 2)
        # Buttons
        self.btn1 = Button(frame,text="Flat Button", relief = FLAT, borderwidth = 2)
        self.btn2 = Button(frame,text="Sunken Button", relief = SUNKEN, borderwidth = 2)
        self.btn3 = Button(frame,text="Ridge Button", relief = RIDGE, borderwidth = 2)
        self.btn4 = Button(frame,text="Raised Button", relief = RAISED, borderwidth = 2)
        self.btn5 = Button(frame,text="Groove Button", relief = GROOVE, borderwidth = 2)
        self.btn1.bind('<ButtonRelease-1>',lambda e: self.BtnCallback(1))
        self.btn2.bind('<ButtonRelease-1>',lambda e: self.BtnCallback(2))
        self.btn3.bind('<ButtonRelease-1>',lambda e: self.BtnCallback(3))
        self.btn4.bind('<ButtonRelease-1>',lambda e: self.BtnCallback(4))
        self.btn5.bind('<ButtonRelease-1>',lambda e: self.BtnCallback(5))
        # Check Boxes
        self.chk1 = Checkbutton(frame, text = "Normal Checkbox",variable=self.Chk1Val)
        self.chk2 = Checkbutton(frame, text = "Checkbox",variable=self.Chk2Val,indicatoron = False)
        self.chk1.bind('<ButtonRelease-1>',lambda e: self.ChkBoxClick(1))
        self.chk2.bind('<ButtonRelease-1>',lambda e: self.ChkBoxClick(2))
        self.btnToggleCB = Button(frame,text="Toggle Cbs")
        self.btnToggleCB.bind('<ButtonRelease-1>',self.btnToggle)
        # Radio Buttons
        self.rb1 = Radiobutton(frame, text = "Radio 1", variable = self.RBVal, value = 1)
        self.rb2 = Radiobutton(frame, text = "Radio 2", variable = self.RBVal, value = 2)
        self.rb3 = Radiobutton(frame, text = "Radio 3", variable = self.RBVal, value = 3)
        self.rb1.bind('<ButtonRelease-1>',lambda e: self.RBClick())
        self.rb2.bind('<ButtonRelease-1>',lambda e: self.RBClick())
        self.rb3.bind('<ButtonRelease-1>',lambda e: self.RBClick())
        # Scrollbar for list box
        self.VScroll = Scrollbar(frame)
        # List Box
        self.lbox = Listbox(frame, height = 5,yscrollcommand = self.VScroll.set) # default height is 10
        self.lbox.bind('<<ListboxSelect>>',self.LBoxSelect)
        self.VScroll.config(command = self.lbox.yview)
        # <<ListboxSelect>> is virtual event
        # Fill the list box
        for ex in self.examples:
            self.lbox.insert(END,ex)
            # Insert([0,ACTIVE,END],item)
        self.btnClearLBox = Button(frame,text = "Clear List",command = self.ClearList)
        self.btnFillLBox = Button(frame,text = "Fill List",command = self.FillList)
        return frame
        
    def PlaceWidgets(self, master):
        frame = master
        # Place the widgets
        frame.grid(column = 0, row = 0)
        # Place the labels
        self.lbl1.grid(column = 0, row = 0, padx = 3, pady = 5)
        self.lbl2.grid(column = 1, row = 0, padx = 3, pady = 5)
        self.lbl3.grid(column = 2, row = 0, padx = 3, pady = 5)
        self.lbl4.grid(column = 3, row = 0, padx = 3, pady = 5)
        self.lbl5.grid(column = 4, row = 0, padx = 3, pady = 5)
        # Place the buttons
        self.btn1.grid(column = 0, row = 1, padx = 3, pady = 3)
        self.btn2.grid(column = 1, row = 1, padx = 3, pady = 3)
        self.btn3.grid(column = 2, row = 1, padx = 3, pady = 3)
        self.btn4.grid(column = 3, row = 1, padx = 3, pady = 3)
        self.btn5.grid(column = 4, row = 1, padx = 3, pady = 3) 
        # Place the Checkboxes and toggle button
        self.btnToggleCB.grid(column = 0, row = 2, padx = 3, pady = 3)                   
        self.chk1.grid(column = 1, row = 2, padx = 3, pady = 3)
        self.chk2.grid(column = 2, row = 2, padx = 3, pady = 3)
        # Place the Radio Buttons and select the first one
        self.rb1.grid(column = 1, row = 3, padx = 3, pady = 3)
        self.rb2.grid(column = 2, row = 3, padx = 3, pady = 3)
        self.rb3.grid(column = 3, row = 3, padx = 3, pady = 3)
        self.RBVal.set("1")
        # Place the Listbox and support buttons
        self.lbox.grid(column = 2, row = 4)
        self.VScroll.grid(column = 3, row = 4, sticky = 'NSW')
        self.btnClearLBox.grid(column = 0, row = 4)
        self.btnFillLBox.grid(column = 1, row = 4)

    def DefineVars(self):
        # Define our resources
        self.Chk1Val = IntVar()
        self.Chk2Val = IntVar()
        self.RBVal = IntVar()
        # List for List box items
        self.examples = ['Item One','Item Two','Item Three','Item Four']
                
    def ClearList(self):
        self.lbox.delete(0,END)
        
    def FillList(self):
        # Note, clear the listbox first...no check is done
        for ex in self.examples:
            self.lbox.insert(END,ex)    
            
    def btnToggle(self,p1):
        self.chk1.toggle()
        self.chk2.toggle()
        print("Check box 1 value is {0}".format(self.Chk1Val.get()))
        print("Check box 2 value is {0}".format(self.Chk2Val.get()))        
        
    def ChkBoxClick(self,val):
        if val == 1:
            print("Check box 1 value is {0}".format(self.Chk1Val.get()))
        elif val == 2:
            print("Check box 2 value is {0}".format(self.Chk2Val.get()))
        
    def BtnCallback(self,val):
        if val == 1:
            print("Flat Button Clicked...")
        elif val == 2:
            print("Sunken Button Clicked...")
        elif val == 3:
            print("Ridge Button Clicked...")
        elif val == 4:
            print("Raised Button Clicked...")
        elif val == 5:
            print("Groove Button Clicked...")
            
    def RBClick(self):
        print("Radio Button clicked - Value is {0}".format(self.RBVal.get()))
    
    def LBoxSelect(self,p1):
        print("Listbox Item clicked")
        items = self.lbox.curselection()
        selitem = items[0]
        print("Index of selected item = {0}".format(selitem))
        print("Text of selected item = {0}".format(self.lbox.get(selitem)))
        
        
root = Tk()
root.geometry('660x260+550+150')
demo = Demo(root)

root.mainloop()
