#!/usr/bin/env python

from PyRTF import *

def TableExample():
    doc = Document()
    ss = doc.StyleSheet
    section = Section()
    doc.Sections.append(section)
        
    thin_edge  = BorderPS(width=20, style=BorderPS.SINGLE)
    thick_edge = BorderPS(width=80, style=BorderPS.SINGLE)
    thin_frame  = FramePS(thin_edge,  thin_edge,  thin_edge,  thin_edge)
    thick_frame = FramePS(thick_edge, thick_edge, thick_edge, thick_edge)
    mixed_frame = FramePS(thin_edge,  thick_edge, thin_edge,  thick_edge)

    table = Table(TabPS.DEFAULT_WIDTH * 3, TabPS.DEFAULT_WIDTH * 3, TabPS.DEFAULT_WIDTH * 3)
    c1 = Cell(Paragraph('R1C1'), thin_frame)
    c2 = Cell(Paragraph('R1C2'))
    c3 = Cell(Paragraph('R1C3'), thick_frame)
    table.AddRow(c1, c2, c3)

    c1 = Cell(Paragraph('R2C1'))
    c2 = Cell(Paragraph('R2C2'))
    c3 = Cell(Paragraph('R2C3'))
    table.AddRow(c1, c2, c3)

    c1 = Cell(Paragraph('R3C1'), mixed_frame)
    c2 = Cell(Paragraph('R3C2'))
    c3 = Cell(Paragraph('R3C3'), mixed_frame)
    table.AddRow(c1, c2, c3)

    section.append(table)


    return doc

def OpenFile(name):
    return file('%s.rtf' % name, 'w')

if __name__ == '__main__':
    DR = Renderer()
    doc = TableExample()
    DR.Write(doc, OpenFile('rtftable-b'))
    print "Finished"
